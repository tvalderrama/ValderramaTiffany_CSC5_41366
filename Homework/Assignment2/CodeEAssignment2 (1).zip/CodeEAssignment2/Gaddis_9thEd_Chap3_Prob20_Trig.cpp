/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float HALF=3.14159265/180;

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int degrees;//Degree input from User
    float sine, //Sine of angle
    cosine, //Cosine of angle
    tangent; //Tangent of angle
    
    
    //Initialize or input i.e. set variable values
    cout<<"Calculate trig functions"<<endl;
    cout<<"Input the angle in degrees."<<endl;
    cin>>degrees;
    
    //Map inputs -> outputs
    sine= sin(degrees*HALF);
    cosine=cos(degrees*HALF);
    tangent=tan(degrees*HALF);
    
    //Display the outputs
    cout<<showpoint;
    cout<<"sin(" <<setprecision(0)<<degrees<<") "<<"= " <<setprecision(4)<<sine<<endl;
    cout<<"cos(" <<setprecision(0)<<degrees<<") "<<"= " <<setprecision(4)<<cosine<<endl;
    cout<<"tan(" <<setprecision(0)<<degrees<<") "<<"= " <<setprecision(4)<<tangent;
    

    //Exit stage right or left!
    return 0;
}
