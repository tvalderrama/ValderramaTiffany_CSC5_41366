/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream> 
#include <iomanip>
#include <cmath>
//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float pay, //User hourly pay
    hours, //Number of hours worked
    grosPay; //Gross pay
    
    
    
    
    //Initialize or input i.e. set variable values
    cout<<"This program calculates the gross paycheck."<<endl;
    cout<<"Input the pay rate in $'s/hr and the number of hours."<<endl;
    cin>>pay;
    cin>>hours;
    
    //Map inputs -> outputs
 if(hours<=40)
    grosPay=hours*pay;
    else if (hours>40)
    grosPay=(40*pay)+(hours-40)*(2*pay);
    //Display the outputs
    cout<<fixed<<showpoint<<setprecision(2)<<"Paycheck = $"<<setw(7)<<grosPay;
   
    //Exit stage right or left!
    return 0;
}
