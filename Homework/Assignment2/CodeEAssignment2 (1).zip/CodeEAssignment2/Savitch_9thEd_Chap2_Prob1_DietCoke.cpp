/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float death, //Amount of sweetner per gram of body mass to kill
    weight, //User weight in lbs
    weightg, //Weight in grams
    sweetner; //Amount of sweetner in can
    int ttlcans; //Total cans user can consume 

    
    
    //Initialize or input i.e. set variable values
    death= 5/35.0f;
    sweetner= 350 *.001f;
    cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
    cout<<"Input the desired dieters weight in lbs."<<endl;
    cin>>weight; 
    //Map inputs -> outputs
    weightg= weight*453.59237f;
    ttlcans= (weightg *death) / sweetner;
    //Display the outputs
    cout<<"The maximum number of soda pop cans"<<endl;
    cout<<"which can be consumed is "<<ttlcans<<" cans";

    //Exit stage right or left!
    return 0;
}

