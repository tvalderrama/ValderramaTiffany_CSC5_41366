/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
  float     mealcst, //Cost of meal before tax and tip
            tax, //Percent of tax added to meal cost
            tip, //Percent of tip added to after sum of meal cost and tax
            tipamt, //Actual amount of tip added to bill
            taxbill, //Tax amount of meal
            ttlbill, //Cost of meal, including tax
            fnlbill; //Total of the final bill
    
    //Initialize Variables
    mealcst= 88.67f;
    tax=0.0675f;
    tip=0.20f;
  
    
    //Map Inputs to Outputs -> Process
            taxbill= mealcst*tax;
            ttlbill=mealcst+taxbill;
            tipamt= ttlbill*tip;
            fnlbill= ttlbill+tipamt;
    
    //Display Inputs/Outputs
            cout<<"Meal cost=$"<<mealcst<<endl;
            cout<<"Tax amount=$"<<taxbill<<endl;
            cout<<"Tip amount=$"<<tipamt<<endl;
            cout<<"Final bill=$"<<fnlbill<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}