/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    int sales, //How much East Coast division made this year
        totlsls; //Total sales after percentage taken accounted for
    float perofTS; //Percentage company will generate of total sales
    
    
    
    //Initialize Variables
    sales= 8600000;
    perofTS= 0.58f;
   
            
    
    //Map Inputs to Outputs -> Process
    totlsls=sales*perofTS;
    
    //Display Inputs/Outputs
    cout<<"East Coast division will generate "<<totlsls<<"this year.";
    
    //Exit the Program - Cleanup
    return 0;
}
