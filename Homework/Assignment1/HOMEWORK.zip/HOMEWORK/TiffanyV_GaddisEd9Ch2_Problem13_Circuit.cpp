/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float circuit, //Cost of circuit board
          profit, //Percentage electronic company sells board at
          prftPr, //Amount of profit being made
          fnlPrice; //Selling price of circuit board
    
    //Initialize Variables
    circuit=14.95;
    profit=0.35f;
      
    
    //Map Inputs to Outputs -> Process
    prftPr=circuit*profit;
    fnlPrice=circuit+prftPr;
    
    //Display Inputs/Outputs
    cout<<"The selling price of a circuit board that costs $"<<circuit<<" is $"<<fnlPrice<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}