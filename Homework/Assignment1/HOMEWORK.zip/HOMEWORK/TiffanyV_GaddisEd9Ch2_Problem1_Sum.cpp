/* 
 * File:   main.cpp
 * Author: Tiffany Valderrama
 * Created on January 10, 2021 7:11 PM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    int num1, //Variable that represents 50
        num2, //Variable that represent 100
        total; // Sum of num1 and num2
    
    
    //Initialize Variables
    num1= 50;
    num2= 100;
    
    
    //Map Inputs to Outputs -> Process
    total= num1+num2;
    
    //Display Inputs/Outputs
    cout<<num1<<"+"<<num2<<"="<<total<<endl;
            
    
    //Exit the Program - Cleanup
    return 0;
}
