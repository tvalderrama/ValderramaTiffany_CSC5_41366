/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    int     shares; //Number of sjares
    float   stock, //Price paid for all stocks
            stockpr, //Price paid per stock
            cmmsn, //Total of commission fee
            cmmsnrt, //Rate of commission fee
            total; //Total amount paid for the shares
    
    //Initialize Variables
    shares=750;
    stockpr=35.00;
    cmmsnrt=2;
    
    //Map Inputs to Outputs -> Process
    stock=shares*stockpr;
    cmmsn=stock* cmmsnrt/100;
    total=stock+cmmsn;
    //Display Inputs/Outputs
    cout<<"The total price paid for shares before commission is $ "<<stock<<endl;
    cout<<"The total commission fee paid for the transaction is $ "<<cmmsn<<endl;
    cout<<"The total cost of shares including commission fees paid for the transaction is $ "<<total<<endl;
  
    
    //Exit the Program - Cleanup
    return 0;
}