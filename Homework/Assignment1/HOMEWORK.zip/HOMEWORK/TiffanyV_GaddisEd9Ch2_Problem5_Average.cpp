/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    int num1, //Variable that represents 28
        num2, //Variable that represents 32
        num3, //Variable that represents 37
        num4, //Variable that represents 24
        num5, //Variable that represents 33
        sum, //Sum of all 5 Variables
        avg; //Average of the 5 variables
    
    //Initialize Variables
    num1=28;
    num2=32;
    num3=37;
    num4=24;
    num5=33;
 
    //Map Inputs to Outputs -> Process
    sum=num1+num2+num3+num4+num5;
    avg=sum/5;    
    
    //Display Inputs/Outputs
     cout<<"The average of"<<num1<<"+"<<num2<<"+"<<num3<<"+"<<num4<<"+"<<num5<<endl;
     cout<<"is approximately "<<avg<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}
