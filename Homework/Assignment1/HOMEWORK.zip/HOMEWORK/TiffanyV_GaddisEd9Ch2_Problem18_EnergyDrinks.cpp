/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    int cstSurv, //Number of customers surveyed
        purcEng, //Number of customers who purchased energy drinks
        purcCit; //Number of customers purchasing citrus drinks
    float prcEngy, //Percentage of surveyed who consume energy drinks
        prcCit; //Percentage of Citrus drinkers
            
    
    //Initialize Variables
    cstSurv=16500;
    prcEngy=0.15f;
    prcCit=0.58f;
    
    //Map Inputs to Outputs -> Process
    purcEng=cstSurv*prcEngy;
    purcCit=purcEng*prcCit;
    
    //Display Inputs/Outputs
    cout<<"Total customers surveyed = "<<cstSurv<<endl;
    cout<<"Customers that are energy drinkers = "<<purcEng<<endl;
    cout<<"Customers that like Citrus flavored energy drinks = "<<purcCit<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}